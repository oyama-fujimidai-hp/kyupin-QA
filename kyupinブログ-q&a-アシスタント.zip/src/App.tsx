/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Search, Loader2, ExternalLink, AlertCircle, BookOpen, Sparkles, HelpCircle, ChevronRight, MessageCircle, Copy, Check, Download, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import { auth, googleProvider } from './lib/firebase';
import { doc, getDocFromServer } from 'firebase/firestore';
import { db } from './lib/firebase';

// Google GenAI SDK Initialization
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

// ✨ マークダウン形式のテキストを読みやすく表示するためのコンポーネント
interface FormattedTextProps {
  text: string;
}

const FormattedText: React.FC<FormattedTextProps> = ({ text }) => {
  if (!text) return null;
  
  const renderInline = (lineText: string) => {
    // 太字の処理 (**テキスト**)
    const parts = lineText.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-white">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  const renderLine = (line: string, index: number) => {
    // 見出しの処理 (###, ##, #)
    if (line.startsWith('### ')) return <h3 key={index} className="text-lg font-bold mt-4 mb-2 text-slate-100">{line.replace('### ', '')}</h3>;
    if (line.startsWith('## ')) return <h2 key={index} className="text-xl font-bold mt-5 mb-3 border-b border-slate-700 pb-1 text-slate-100">{line.replace('## ', '')}</h2>;
    if (line.startsWith('# ')) return <h1 key={index} className="text-2xl font-bold mt-6 mb-4 border-b border-slate-700 pb-2 text-white">{line.replace('# ', '')}</h1>;
    // リストの処理 (-, *)
    if (line.startsWith('- ') || line.startsWith('* ')) return <li key={index} className="ml-5 list-disc mb-1 text-slate-300">{renderInline(line.substring(2))}</li>;
    
    // 通常の段落
    return <p key={index} className="mb-2 text-slate-300">{renderInline(line)}</p>;
  };

  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let inList = false;
  let listItems: React.ReactNode[] = [];

  lines.forEach((line, index) => {
    if (line.startsWith('- ') || line.startsWith('* ')) {
      listItems.push(renderLine(line, index));
      inList = true;
    } else {
      if (inList) {
        elements.push(<ul key={`ul-${index}`} className="my-2 space-y-1">{listItems}</ul>);
        listItems = [];
        inList = false;
      }
      if (line.trim() === '') {
        // 空行で適度な余白を作る
        elements.push(<div key={`empty-${index}`} className="h-3"></div>);
      } else {
        elements.push(renderLine(line, index));
      }
    }
  });

  // 最後にリストが残っていた場合の処理
  if (inList) {
    elements.push(<ul key={`ul-end`} className="my-2 space-y-1">{listItems}</ul>);
  }

  return <div className="text-slate-700 leading-relaxed text-lg">{elements}</div>;
};

interface Source {
  uri?: string;
  title?: string;
}

const RECOMMENDED_KEYWORDS = [
  "統合失調症", "うつ病", "パキシル", "睡眠薬", "減薬", "副作用", "漢方薬", "発達障害"
];

export default function App() {
  const [query, setQuery] = useState('');
  const [answer, setAnswer] = useState('');
  const [sources, setSources] = useState<Source[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  // ✨ Auth State
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  
  // ✨ LLM機能用の追加状態
  const [simplifiedAnswer, setSimplifiedAnswer] = useState('');
  const [followUpQuestions, setFollowUpQuestions] = useState<string[]>([]);
  const [isSimplifying, setIsSimplifying] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  
  // ✨ コピー・保存機能用の状態
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });

    // CRITICAL CONSTRAINT: Test connection to Firestore
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error("Login failed", err);
      setError("ログインに失敗しました。");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  const handleQuickSearch = (keyword: string) => {
    setQuery(keyword);
    // Since setQuery is asynchronous, we call a modified handleSearch logic or directly use the keyword
    performAPIRequest(keyword);
  };

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;
    performAPIRequest(query);
  };

  // ✨ 追加機能2: 関連する質問を提案する
  const generateFollowUpQuestions = async (currentAnswer: string, currentQuery: string) => {
    if (!currentAnswer) return;
    setIsSuggesting(true);
    const promptText = `ユーザーが「${currentQuery}」という質問をし、以下の回答を得ました。\n\n回答: ${currentAnswer}\n\nこの内容を踏まえて、ユーザーが次に疑問に思いそうな、さらに深掘りする関連質問を、精神科医のブログの内容に即した形で3つ提案してください。`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [{ parts: [{ text: promptText }] }],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        }
      });
      const text = response.text;
      if (text) {
        const questions = JSON.parse(text);
        setFollowUpQuestions(questions);
      }
    } catch (err) {
      console.error("Suggestion API Error:", err);
    } finally {
      setIsSuggesting(false);
    }
  };

  const performAPIRequest = async (searchQuery: string) => {
    setLoading(true);
    setError('');
    setAnswer('');
    setSources([]);
    setSimplifiedAnswer('');
    setFollowUpQuestions([]);

    // AIの役割とルールを定義
    const systemInstruction = `あなたは「精神科医kyupinのブログ(https://ameblo.jp/kyupin/)」の情報をもとにユーザーの質問に答える専用のアシスタントです。
以下のルールを厳密に守ってください：
1. 提供されたGoogle Searchツールを利用して、情報を検索してください。
2. 検索結果（対象ブログ内の情報）に基づいてのみ、質問に対する回答を作成してください。
3. もし、検索結果の中に質問に対する答えが含まれていない場合や、関連する情報を見つからない場合は、あなたの一般的な知識から推測して答えることは**絶対にしないでください**。その場合は必ず「申し訳ありませんが、ブログ内にはその質問に対する答えが見つかりませんでした。」と回答してください。
4. 回答は丁寧で自然な日本語で行ってください。`;

    // サイト指定検索を行うようにプロンプトを構築
    const promptText = `以下の質問について、"site:ameblo.jp/kyupin/" という条件でGoogle検索を行った結果をもとに答えてください。\n\n質問: ${searchQuery}`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: promptText,
        config: {
          systemInstruction: systemInstruction,
          tools: [{ googleSearch: {} }] as any,
          toolConfig: { includeServerSideToolInvocations: true } as any,
        }
      });

      const text = response.text;
      
      if (text) {
        setAnswer(text);
        
        // 元の回答が設定されたら、自動的に次の質問を生成
        generateFollowUpQuestions(text, searchQuery);
        
        // 参考元URL（グラウンディングデータ）の抽出と重複排除
        const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
        const chunks = groundingMetadata?.groundingChunks;
        
        const uniqueSources: Source[] = [];
        const seenUris = new Set<string>();
        
        if (chunks) {
          chunks.forEach((chunk: any) => {
            const web = chunk.web;
            if (web?.uri && !seenUris.has(web.uri)) {
              seenUris.add(web.uri);
              uniqueSources.push({
                uri: web.uri,
                title: web.title || web.uri
              });
            }
          });
        }
        
        // Fallback to attributions if chunks are missing (legacy/other versions)
        if (uniqueSources.length === 0) {
          const rawSources = (groundingMetadata as any)?.groundingAttributions?.map((a: any) => ({
            uri: a.web?.uri,
            title: a.web?.title
          })) || [];
          
          for (const source of rawSources) {
            if (source.uri && !seenUris.has(source.uri)) {
              seenUris.add(source.uri);
              uniqueSources.push(source);
            }
          }
        }
        
        setSources(uniqueSources);
      } else {
        setAnswer("回答を生成できませんでした。");
      }
    } catch (err: any) {
      console.error("API Search Error:", err);
      setError("API呼び出しでエラーが発生しました。設定メニューでAPIキーが正しく設定されているか（または無料枠の上限に達していないか）をご確認ください。");
    } finally {
      setLoading(false);
    }
  };

  // ✨ 追加機能1: 回答をわかりやすく言い換える
  const handleSimplify = async () => {
    if (!answer) return;
    setIsSimplifying(true);
    const promptText = `以下の回答は精神科医のブログに基づいていますが、専門用語が含まれていて難しい場合があります。医療知識のない一般の人にもわかりやすく、噛み砕いた表現で要約して説明し直してください。\n\n元の回答:\n${answer}`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [{ parts: [{ text: promptText }] }],
        config: {
          systemInstruction: "あなたは優しくてわかりやすい医療解説アシスタントです。",
        }
      });
      const text = response.text;
      if (text) setSimplifiedAnswer(text);
    } catch (err) {
      console.error("API Error:", err);
    } finally {
      setIsSimplifying(false);
    }
  };

  // ✨ コピー機能
  const handleCopy = async () => {
    const textToCopy = `【質問】\n${query}\n\n【回答】\n${answer}\n\n${simplifiedAnswer ? `【やさしい解説】\n${simplifiedAnswer}\n\n` : ''}【参考元】\n${sources.map(s => s.uri).join('\n')}`;
    
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Copy failed', err);
    }
  };

  // ✨ 保存機能（テキストファイルとしてダウンロード）
  const handleDownload = () => {
    const textToSave = `【質問】\n${query}\n\n【回答】\n${answer}\n\n${simplifiedAnswer ? `【やさしい解説】\n${simplifiedAnswer}\n\n` : ''}【参考元】\n${sources.map(s => s.uri).join('\n')}`;
    const blob = new Blob([textToSave], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeQuery = query.replace(/[\\/:*?"<>|]/g, '_').substring(0, 15) || '質問結果';
    link.download = `ブログQA_${safeQuery}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-bg-dark text-slate-200 p-4 font-sans selection:bg-blue-500/30">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* ヘッダー部分 */}
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row items-center justify-between gap-6 py-4 px-2"
        >
          <div className="flex items-center space-x-4">
            <div className="bg-blue-600 p-2.5 rounded-xl text-white shadow-lg shadow-blue-500/20">
              <BookOpen size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center whitespace-nowrap">
                Medical Blog Insights
                <span className="text-[10px] font-normal opacity-40 ml-2 px-1.5 py-0.5 border border-white/20 rounded uppercase tracking-tighter">v2.5</span>
              </h1>
              <p className="text-xs text-slate-400">精神科医kyupinのブログ専用 Q&A アシスタント</p>
            </div>
          </div>

          <div className="flex-1 max-w-2xl w-full space-y-3">
            <form onSubmit={handleSearch} className="w-full">
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="ブログについて聞きたいことを入力してください..."
                  className="w-full bg-slate-900 border border-slate-700/50 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-blue-500/50 focus:ring-4 focus:ring-blue-500/10 transition-all shadow-inner"
                  disabled={loading}
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  {loading ? (
                    <Loader2 size={16} className="animate-spin text-blue-500 mr-2" />
                  ) : (
                    <button
                      type="submit"
                      disabled={!query.trim()}
                      className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-bold rounded-lg transition-all active:scale-95"
                    >
                      質問
                    </button>
                  )}
                </div>
              </div>
            </form>
            
            {/* 次の質問提案ワード (回答生成後のみ表示) */}
            {followUpQuestions.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 px-1 py-1">
                <span className="text-[10px] text-emerald-500 uppercase tracking-widest font-black mr-2">
                  NEXT QUESTIONS:
                </span>
                {followUpQuestions.map((word) => (
                  <button
                    key={word}
                    onClick={() => handleQuickSearch(word)}
                    disabled={loading}
                    className="text-[10px] px-3 py-1 border rounded-full transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed font-medium bg-emerald-900/40 hover:bg-emerald-800/60 border-emerald-500/20 text-emerald-300 hover:text-emerald-100"
                  >
                    {word}
                  </button>
                ))}
                {isSuggesting && <Loader2 size={12} className="animate-spin text-emerald-500 ml-2" />}
              </div>
            )}
          </div>

          {/* Auth Button */}
          <div className="flex items-center gap-3">
            {!authLoading && (
              user ? (
                <div className="flex items-center gap-3 bg-slate-900/50 p-1.5 pr-4 rounded-2xl border border-slate-800">
                  <img 
                    src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} 
                    alt={user.displayName || "User"} 
                    className="w-8 h-8 rounded-xl object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="hidden sm:block text-left">
                    <p className="text-[10px] font-bold text-white truncate max-w-[100px] leading-tight">
                      {user.displayName || user.email}
                    </p>
                    <button 
                      onClick={handleLogout}
                      className="text-[9px] text-slate-500 hover:text-red-400 transition-colors uppercase font-black"
                    >
                      Logout
                    </button>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="sm:hidden text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <LogOut size={16} />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleLogin}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-600/30 rounded-xl text-xs font-bold transition-all whitespace-nowrap"
                >
                  <LogIn size={16} />
                  Googleでログイン
                </button>
              )
            )}
          </div>
        </motion.header>

        {/* エラー表示 */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-blue-600/70 text-red-400 p-5 rounded-2xl flex items-center gap-4 border border-blue-400/50 overflow-hidden shadow-2xl shadow-blue-900/40"
            >
              <AlertCircle className="shrink-0 text-red-500" size={24} />
              <p className="text-sm font-medium tracking-wide flex-1">{error}</p>
            </motion.div>
          )}
        </AnimatePresence>

          {/* メインコンテンツエリア */}
          <main className="min-h-[60vh]">
            
            {/* メイン回答 (フル幅) */}
            <section className="flex flex-col space-y-6 max-w-4xl mx-auto">
              {!loading && answer ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="glass-panel flex-1 p-10 relative overflow-hidden group shadow-2xl shadow-blue-900/10"
                >
                  {/* 装飾的なバッジ */}
                  <div className="absolute top-8 right-10 text-[10px] uppercase tracking-[0.2em] text-blue-400 font-black border border-blue-500/40 px-2.5 py-1 rounded-md pointer-events-none bg-blue-900/10">
                    AI GROUNDED RESPONSE
                  </div>

                  <div className="space-y-8">
                    <div className="flex items-center gap-3 mb-6">
                      <span className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.6)]"></span>
                      <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center whitespace-nowrap">
                        検索結果からの回答
                      </h2>
                    </div>

                  <div className="relative">
                    <FormattedText text={answer} />
                  </div>

                  {/* 参考元URLの表示 */}
                  {sources.length > 0 && (
                    <div className="mt-8 pt-6 border-t border-slate-700/50 space-y-4">
                      <h3 className="text-xs font-bold text-slate-500 uppercase flex items-center tracking-wider text-nowrap">
                        <ExternalLink size={14} className="mr-2" />
                        情報源となったブログ記事
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {sources.map((source, index) => (
                          <a
                            key={index}
                            href={source.uri}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center gap-2 text-xs text-blue-400 hover:text-blue-300 hover:underline bg-blue-50/5 p-3 rounded-xl border border-blue-500/10 transition-all hover:bg-blue-500/10"
                          >
                            <span className="line-clamp-1">{source.title || source.uri}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 深掘りヒント (動的に生成された次の質問) */}
                  {(followUpQuestions.length > 0 || isSuggesting) && (
                    <div className="mt-8 pt-6 border-t border-slate-700/50 space-y-4">
                      <h3 className="text-xs font-bold text-emerald-400 uppercase flex items-center tracking-wider text-nowrap">
                        <HelpCircle size={14} className="mr-2" />
                        深掘りヒント
                      </h3>
                      {isSuggesting ? (
                        <div className="flex items-center gap-3 py-2 px-1">
                          <Loader2 size={14} className="animate-spin text-emerald-500" />
                          <span className="text-xs text-slate-500 animate-pulse">次の質問を考えています...</span>
                        </div>
                      ) : (
                        <div className="flex flex-wrap gap-2">
                          {followUpQuestions.map((q, idx) => (
                            <button
                              key={idx}
                              onClick={() => handleQuickSearch(q)}
                              className="text-left px-4 py-2.5 rounded-xl bg-emerald-500/5 border border-emerald-500/10 text-xs text-slate-300 hover:text-emerald-300 hover:bg-emerald-500/10 hover:border-emerald-500/30 transition-all flex items-center justify-between group"
                            >
                              <span className="font-medium">{q}</span>
                              <ChevronRight size={12} className="ml-2 text-slate-600 group-hover:text-emerald-400 opacity-0 group-hover:opacity-100 transition-all" />
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* アクションボタン */}
                <div className="flex items-center gap-3 mt-10 pt-8 border-t border-white/5">
                  <button
                    onClick={handleCopy}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-slate-800/60 hover:bg-slate-700/80 text-slate-200 border border-white/5 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95"
                  >
                    {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={16} className="text-slate-400" />}
                    {copied ? "コピー完了" : "結果をコピー"}
                  </button>
                  <button
                    onClick={handleDownload}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-slate-800/60 hover:bg-slate-700/80 text-slate-200 border border-white/5 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95"
                  >
                    <Download size={16} className="text-slate-400" />
                    保存する
                  </button>
                </div>
              </motion.div>
            ) : !loading && !answer ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-500 space-y-6 py-20">
                <div className="flex flex-col items-center space-y-6 opacity-40">
                  <div className="w-24 h-24 bg-slate-900/80 rounded-full flex items-center justify-center border border-slate-700/50 shadow-inner">
                    <Search size={44} className="text-slate-600" />
                  </div>
                  <p className="text-sm font-medium tracking-wide">質問を入力して検索を開始してください</p>
                </div>
              </div>
            ) : null}

            {loading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass-panel flex-1 flex flex-col items-center justify-center space-y-6 py-20"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-full"></div>
                  <Loader2 size={48} className="animate-spin text-blue-500 relative z-10" />
                </div>
                <div className="text-center space-y-2">
                  <p className="text-sm font-medium text-slate-300 animate-pulse">ブログの過去記事を検索中...</p>
                  <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em]">Analyzing Archives</p>
                </div>
              </motion.div>
            )}
           </section>
        </main>
      </div>

      <footer className="max-w-7xl mx-auto mt-12 mb-12 text-center border-t border-white/5 pt-12">
        <div className="text-slate-600 font-bold text-[10px] uppercase tracking-[0.4em] mb-4">
          Internal Health Knowledge Base
        </div>
      </footer>
    </div>
  );
}
